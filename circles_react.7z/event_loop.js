function eventLoop(svg, systemParamaters, settings) {
	
	let circle_images = [];
	let circles = systemParamaters.circles; 
	
	let event_loop = setInterval(() => {

		//Apply acceleration and then adjust images. 
		for(i = 0; i < circles.length; i++) {
			circles[i].speedX += circles[i].accelerationX;
			circles[i].speedY += circles[i].accelerationY; 

			/*if(settings.drag) {
				modelDrag(circles, settings.drag_value);
			}*/

			circle_images[i] = {imX: circles[i].cx + circles[i].speedX, 
								imY: circles[i].cy + circles[i].speedY}
		}

		//Detect collisions
		let collisions_detected = false;
		let loop_number = 0;
		do {
			loop_number++;
			collisions_detected = wallColide(circles, circle_images, svg, systemParamaters);
			
			if(!collisions_detected) {
				collisions_detected = circleCollide(circle_images, circles);
			} else {
				circleCollide(circle_images, circles);
			}
		} while(collisions_detected && 
			(loop_number < systemParamaters.collision_handling_precision));
			
		for(i = 0; i < circles.length; i++) {
			let x = circles[i].cx = circle_images[i].imX; 
			let y = circles[i].cy = circle_images[i].imY;
			let circle = document.querySelector('#' + 'circle_' + circles[i].id);
			circle.setAttributeNS(null, 'cx', x);
			circle.setAttributeNS(null, 'cy', y);
		}
	
	}, systemParamaters.rendering_precision);

	return event_loop; 
}