function enablePlayerControls(systemParamaters) {
    let circles = systemParamaters; 

    
}