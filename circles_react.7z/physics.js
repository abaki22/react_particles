function wallColide(circles, circle_images, svg, systemParamaters) {
		let collisions_detected = false; 
		let boundsX = systemParamaters.boundsX;
		let boundsY = systemParamaters.boundsY;
		for(i = 0; i < circles.length; i++) {
			if(circle_images[i].imX + circles[i].r >= boundsX) {
				circles[i].speedX = -circles[i].speedX * circles[i].elasticity;
				circle_images[i].imX = circles[i].cx + circles[i].speedX;
				collisions_detected = true; 
			} else if(circle_images[i].imX - circles[i].r <= 0) {
				circles[i].speedX = -circles[i].speedX * circles[i].elasticity;
				circle_images[i].imX = circles[i].cx + circles[i].speedX;	
				collisions_detected = true; 
			}
			
			if(circle_images[i].imY + circles[i].r >= boundsY) {
				circles[i].speedY = -circles[i].speedY * circles[i].elasticity;
				circle_images[i].imY = circles[i].cy + circles[i].speedY;
				collisions_detected = true; 
			} else if(circle_images[i].imY - circles[i].r <= 0) {
				circles[i].speedY = -circles[i].speedY * circles[i].elasticity;
				circle_images[i].imY = circles[i].cy + circles[i].speedY;	
				collisions_detected = true; 
			}
		}
		return collisions_detected;
}

function circleCollide(circle_images, circles) {
		let collisions_detected = false; 
		for(i = 0; i < circles.length; i++) {
			for(second_i = i + 1; second_i < circles.length; second_i++) {
				if(Math.pow((circle_images[second_i].imX - circle_images[i].imX), 2) + 
				   Math.pow((circle_images[i].imY - circle_images[second_i].imY), 2) 
				   <= Math.pow((circles[i].r + circles[second_i].r), 2)) {
						
						let vx1 = circles[i].speedX;
						let vy1 = circles[i].speedY;
						let vx2 = circles[second_i].speedX;
						let vy2 = circles[second_i].speedY;
						
						let m1 = circles[i].mass;
						let m2 = circles[second_i].mass;
						
						circles[i].speedX = (vx1 * (m1 - m2) + (2 * m2 * vx2))/(m1 + m2);
						circles[i].speedY = (vy1 * (m1 - m2) + (2 * m2 * vy2))/(m1 + m2);
						circles[second_i].speedX = (vx2 * (m2 - m1) + (2 * m1 * vx1))/(m1 + m2);
						circles[second_i].speedY = (vy2 * (m2 - m1) + (2 * m1 * vy1))/(m1 + m2);
						
						circle_images[i].imX = circles[i].cx + circles[i].speedX * circles[i].elasticity;
						circle_images[i].imY = circles[i].cy + circles[i].speedY * circles[i].elasticity;
						circle_images[second_i].imX = circles[second_i].cx + circles[second_i].speedX;
						circle_images[second_i].imY = circles[second_i].cy + circles[second_i].speedY;
						collisions_detected = true;
				   }
			}
		}
		return collisions_detected; 
}

function modelDrag(circles) {
	//  D = Cd * (density * velocity^2)/2 * reference_area
	//  Assume reference area is half the circle's circumference
	//  what do
	for(i = 0; i < circles.length; i++) {
		//What goes in here, @Marie, @Jacob
	}
}