'use strict'; 

class toggleWallsButton extends React.Component {
    constructor(props) {
        super(props);
        this.state = { toggled: true };
    }

    render() {
        return React.createElement(
            'button',
            {   id: "toggle_walls_button",
                className: "btn-success",
                onClick: () => {
                    this.toggleWallsButton();
                    this.toggle_button_status(); 
                }
            },
            'Toggle Walls'
        )
    }

    toggleWallsButton() {
        this.state.toggled = !this.state.toggled;
        if(this.state.toggled) {
            this.props.settings.walls = true;
			this.props.systemFlags.popCirclesInWallsFlag = true;
        } else {
            this.props.settings.walls = false;
        }
    }

    toggle_button_status() {
        if(this.state.toggled) {
            let thisButton = document.querySelector('#toggle_walls_button');
            thisButton.classList.remove("btn-primary");
            thisButton.classList.add("btn-success");
        } else {
            let thisButton = document.querySelector('#toggle_walls_button');
            thisButton.classList.remove("btn-success");
            thisButton.classList.add("btn-primary");
        }
    }
}