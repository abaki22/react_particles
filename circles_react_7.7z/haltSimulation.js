'use strict'; 

class haltSim extends React.Component {

    constructor(props) {
        
    }

}