function eventLoop(svg, systemParamaters, settings) {
	
	let circle_images = systemParamaters.circle_images;
	let circles = systemParamaters.circles; 
	
	let event_loop = setInterval(() => {

		//Compute acceleration, apply it and then adjust images. 
		let accelX, accelY; 
		for(i = 0; i < circles.length; i++) {
			accelX = accelY = 0;
			for (const [key, value] of Object.entries(circles[i].accelerationXFactors)) {
				accelX += value;
				if(key != 'player') {
					circles[i].accelerationXFactors[key] = 0; 
				}
			}

			for (const [key, value] of  Object.entries(circles[i].accelerationYFactors)) {
				accelY += value; 
				if(key != 'player') {
					circles[i].accelerationYFactors[key] = 0;
				}
			}

			circles[i].speedX += accelX;
			circles[i].speedY += accelY; 

			if(settings.drag) {
				modelDrag(circles, settings.drag_value);
			}

			if(settings.gravity) {
				modelGravity(circles);
			}

			circle_images[i] = {imX: circles[i].cx + circles[i].speedX, 
								imY: circles[i].cy + circles[i].speedY}
		}

		//Detect collisions
		let collisions_detected = false;
		let loop_number = 0;
		do {
			loop_number++;
			collisions_detected = wallCollide(circles, circle_images, systemParamaters);
			
			if(!collisions_detected) {
				collisions_detected = circleCollide(circle_images, circles);
			} else {
				circleCollide(circle_images, circles);
			}
		} while(collisions_detected && 
			(loop_number < systemParamaters.collision_handling_precision));
		
		if(systemParamaters.systemFlags.popCirclesInWallsFlag) {
			systemParamaters.systemFlags.popCirclesInWallsFlag = false; 
			popCirclesInWalls(circles, circle_images, 
							  systemParamaters);
		}
			
		for(i = 0; i < circles.length; i++) {
			let x = circles[i].cx = circle_images[i].imX; 
			let y = circles[i].cy = circle_images[i].imY;
			let circle = document.querySelector('#' + 'circle_' + circles[i].id);
			circle.setAttributeNS(null, 'cx', x);
			circle.setAttributeNS(null, 'cy', y);
		}
	
	}, systemParamaters.rendering_precision);

	return event_loop; 
}