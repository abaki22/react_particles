'use strict';

document.addEventListener('DOMContentLoaded', () => {
	let svg = document.querySelector('#stage');
	let system_params =	startSystem(svg);
	renderUI(system_params);
});

function startSystem(svg) {
	let boundryX = parseInt(svg.getAttribute('width'));
	let boundryY = parseInt(svg.getAttribute('height'));
	let settings = { gravity: false, drag: true, walls: true };
	let systemFlags = { popCirclesInWallsFlag: false };
	let systemParamaters = { boundsX: boundryX, boundsY: boundryY, 
								rendering_precision: 0.5, circles: null,
								circle_images: [],
								running: true,
								collision_handling_precision: 5,
								settings: settings,
								systemFlags: systemFlags };
	//let system_events = { player_keyup_controls: null, player_keydown_controls: null }
	
	let max_size = 15;
	let min_size = 10;
	let max_speed = 1; 
	let circle_number = 50;
	let density = 50;
	
	systemParamaters.circles = 
	generateCircles(circle_number, min_size, max_size, svg, max_speed, density,
													systemParamaters);
	
	let event_loop = eventLoop(svg, systemParamaters, settings);
	return systemParamaters;
	
}

function renderUI (system_params) {
	let elContainer = document.querySelector("#player_keyboard_controls_toggle_container");
	ReactDOM.render(React.createElement(togglePlayerKeyboardControls, system_params), elContainer);
	
	elContainer = document.querySelector('#toggle_gravity_button_container');
	ReactDOM.render(React.createElement(toggleGravityButton, system_params), elContainer)
	
	elContainer = document.querySelector('#toggle_walls_button_container');
	ReactDOM.render(React.createElement(toggleWallsButton, system_params), elContainer)
}

