'use strict'; 

function enablePlayerControls(systemParamaters) {
    let circles = systemParamaters.circles; 

    controls_listeners_keydown = (event => {
        if (event.keyCode == 40) {
            for(let i = 0; i < circles.length; i++) {
                if(circles[i].accelerationYFactors.player < 0.01) {
                    circles[i].accelerationYFactors.player += 0.001;
                } 
            }
        }

        if (event.keyCode == 38) {
            for(let i = 0; i < circles.length; i++) {
                if(circles[i].accelerationYFactors.player > -0.01) {
                    circles[i].accelerationYFactors.player -= 0.001;
                }
            }
        }

        if (event.keyCode == 39) {
            for(let i = 0; i < circles.length; i++) {
                if(circles[i].accelerationXFactors.player < 0.01) {
                    circles[i].accelerationXFactors.player += 0.001;
                }
            }
        }

        if (event.keyCode == 37) {
            for(let i = 0; i < circles.length; i++) {
                if(circles[i].accelerationXFactors.player > -0.01) {
                    circles[i].accelerationXFactors.player -= 0.001;
                }
            }
        }
    });
    
    
    window.addEventListener("keydown", controls_listeners_keydown, true);

    controls_listeners_keyup = (event => {
        for(let i = 0; i < circles.length; i++) {
            circles[i].accelerationYFactors.player = 0;
            circles[i].accelerationXFactors.player = 0; 
        }
    });
    
    window.addEventListener("keyup", controls_listeners_keyup, true); 
    
    return {controls_listeners_keydown, controls_listeners_keyup};

}