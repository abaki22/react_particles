function wallColide(circles, circle_images, svg, systemParamaters) {
		let collisions_detected = false; 
		let boundsX = systemParamaters.boundsX;
		let boundsY = systemParamaters.boundsY;
		for(let i = 0; i < circles.length; i++) {
			if(circle_images[i].imX + circles[i].r >= boundsX) {
				circles[i].speedX = -circles[i].speedX * circles[i].elasticity;
				circle_images[i].imX = circles[i].cx + circles[i].speedX;
				collisions_detected = true; 
			} else if(circle_images[i].imX - circles[i].r <= 0) {
				circles[i].speedX = -circles[i].speedX * circles[i].elasticity;
				circle_images[i].imX = circles[i].cx + circles[i].speedX;	
				collisions_detected = true; 
			}
			
			if(circle_images[i].imY + circles[i].r >= boundsY) {
				circles[i].speedY = -circles[i].speedY * circles[i].elasticity;
				circle_images[i].imY = circles[i].cy + circles[i].speedY;
				collisions_detected = true; 
			} else if(circle_images[i].imY - circles[i].r <= 0) {
				circles[i].speedY = -circles[i].speedY * circles[i].elasticity;
				circle_images[i].imY = circles[i].cy + circles[i].speedY;	
				collisions_detected = true; 
			}
		}
		return collisions_detected;
}

function circleCollide(circle_images, circles) {
		let collisions_detected = false; 
		for(let i = 0; i < circles.length; i++) {
			for(let second_i = i + 1; second_i < circles.length; second_i++) {
				if(Math.pow((circle_images[second_i].imX - circle_images[i].imX), 2) + 
				   Math.pow((circle_images[i].imY - circle_images[second_i].imY), 2) 
				   <= Math.pow((circles[i].r + circles[second_i].r), 2)) {
						
						let vx1 = circles[i].speedX;
						let vy1 = circles[i].speedY;
						let vx2 = circles[second_i].speedX;
						let vy2 = circles[second_i].speedY;
						
						let m1 = circles[i].mass;
						let m2 = circles[second_i].mass;
						
						circles[i].speedX = (vx1 * (m1 - m2) + (2 * m2 * vx2))/(m1 + m2);
						circles[i].speedY = (vy1 * (m1 - m2) + (2 * m2 * vy2))/(m1 + m2);
						circles[second_i].speedX = (vx2 * (m2 - m1) + (2 * m1 * vx1))/(m1 + m2);
						circles[second_i].speedY = (vy2 * (m2 - m1) + (2 * m1 * vy1))/(m1 + m2);
						
						circle_images[i].imX = circles[i].cx + circles[i].speedX * circles[i].elasticity;
						circle_images[i].imY = circles[i].cy + circles[i].speedY * circles[i].elasticity;
						circle_images[second_i].imX = circles[second_i].cx + circles[second_i].speedX;
						circle_images[second_i].imY = circles[second_i].cy + circles[second_i].speedY;
						collisions_detected = true;
				   }
			}
		}
		return collisions_detected; 
}

function modelGravity(circles) {
	for(let i = 0; i < circles.length; i++) {
		circles[i].accelerationYFactors.gravity = 0.00098;
	}
}


function modelDrag(circles) {
	//  D = Cd * (density * velocity^2)/2 * reference_area
	// 1/2 p u^2 CD A
	//  Assume reference area is half the circle's circumference
	//  CD is 1.17, Ro is 1.225

	//Total drag
	let d_x;
	let d_y;
	//Drag coefficient
	let cD = 1.17;
	//Density
	let Ro = 1.225; 
	let area; 
	let accelX; 
	let accelY; 
	//Direction
	let dir_x, dir_y;

	//Assumption: half circumference is the "Area". This might not be a reasonable assumption. 
	//Credits to Jacob and Marie for helping me with this. 
	for(let i = 0; i < circles.length; i++) {
		area = Math.PI * circles[i].r; 

		dir_x = Math.sign(circles[i].speedX);
		dir_y = Math.sign(circles[i].speedY);

		d_x = cD * (Ro * Math.pow(circles[i].speedX, 2))/2 * area; 
		d_y = cD * (Ro * Math.pow(circles[i].speedY, 2))/2 * area; 

		if(circles[i].mass >= 1) {
			accelX = (d_x * -1 * dir_x)/circles[i].mass;
			accelY = (d_y * -1 * dir_y)/circles[i].mass; 
		}


		circles[i].accelerationXFactors.drag = accelX;
		circles[i].accelerationYFactors.drag = accelY; 
	}
}