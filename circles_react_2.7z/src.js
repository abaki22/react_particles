'use strict';

document.addEventListener('DOMContentLoaded', () => {
	let svg = document.querySelector('#stage');
	startSystem(svg);
});

function startSystem(svg) {
	let boundryX = parseInt(svg.getAttribute('width'));
	let boundryY = parseInt(svg.getAttribute('height'));
	let systemParamaters = { boundsX: boundryX, boundsY: boundryY, 
								rendering_precision: 5, circles: null,
								running: true,
								collision_handling_precision: 20};
	let settings = { gravity: false, drag: true, drag_value: 0.0001 };
	
	let max_size = 30;
	let min_size = 10;
	let max_speed = 1; 
	let circle_number = 100;
	let density = 25;
	
	systemParamaters.circles = 
	generateCircles(circle_number, min_size, max_size, svg, max_speed, density,
													systemParamaters);
	
	enablePlayerControls(systemParamaters);
	let event_loop = eventLoop(svg, systemParamaters, settings);
	
}