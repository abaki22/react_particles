function enablePlayerControls(systemParamaters) {
    let circles = systemParamaters.circles; 

    controls_listeners_keydown = window.addEventListener("keydown", event => {
        if (event.keyCode == 40) {
            for(let i = 0; i < circles.length; i++) {
                if(circles[i].accelerationYFactors.player < 0.01) {
                    circles[i].accelerationYFactors.player += 0.001;
                } 
            }
        }

        if (event.keyCode == 38) {
            for(let i = 0; i < circles.length; i++) {
                if(circles[i].accelerationYFactors.player > -0.01) {
                    circles[i].accelerationYFactors.player -= 0.001;
                }
            }
        }

        if (event.keyCode == 39) {
            for(let i = 0; i < circles.length; i++) {
                if(circles[i].accelerationXFactors.player < 0.01) {
                    circles[i].accelerationXFactors.player += 0.001;
                }
            }
        }

        if (event.keyCode == 37) {
            for(let i = 0; i < circles.length; i++) {
                if(circles[i].accelerationXFactors.player > -0.01) {
                    circles[i].accelerationXFactors.player -= 0.001;
                }
            }
        }
    });

    controls_listeners_keyup = window.addEventListener("keyup", event => {
        for(let i = 0; i < circles.length; i++) {
            circles[i].accelerationYFactors.player = 0;
            circles[i].accelerationXFactors.player = 0; 
        }
    }); 
    
}