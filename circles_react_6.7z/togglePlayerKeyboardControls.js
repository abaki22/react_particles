'use strict'; 

class togglePlayerKeyboardControls extends React.Component {
    constructor(props) {
        super(props);
        this.state = { toggled: false,  
                       player_keydown_controls: null,
                       player_keyup_controls: null}; 
    }

    render() {
        return React.createElement(
            'button',
            { id: "toggle_player_keyboard_controls_button", 
              className: "btn-primary",
              onClick: () => {
                    this.toggle_keyboard_controls_player();
                    this.toggle_button_status(); 
                }
            },
            'Toggle Player Keyboard Controls'
        );
    }

    toggle_keyboard_controls_player() {
        this.state.toggled = !this.state.toggled;
        if(this.state.toggled) {
            let events = enablePlayerControls(this.props);
            this.player_keyup_controls = events.controls_listeners_keyup;
            this.player_keydown_controls = events.controls_listeners_keydown;
        } else {
            //Turn off player acceleration on all circles before releasing event listeners.
            for(let i = 0; i < this.props.circles.length; i++) {
                this.props.circles[i].accelerationYFactors.player = 0;
                this.props.circles[i].accelerationXFactors.player = 0; 
            }

            window.removeEventListener("keyup", this.player_keyup_controls, true);
            window.removeEventListener("keydown", this.player_keydown_controls, true);
        }
    }

    toggle_button_status() {
        if(!this.state.toggled) {
            let thisButton = document.querySelector('#toggle_player_keyboard_controls_button');
            thisButton.classList.remove("btn-success");
            thisButton.classList.add("btn-primary");
        } else {
            let thisButton = document.querySelector('#toggle_player_keyboard_controls_button');
            thisButton.classList.remove("btn-primary");
            thisButton.classList.add("btn-success");
        }
    }
}