function generateCircles(circle_number, min_size, max_size, svg, max_speed,
						 density, systemParamaters) {
	let circles = [];
	let x = max_size;
	let y = max_size; 
	
	for(i = 0; i < circle_number; i++) {
		let size_r = Math.random() * (max_size - min_size) + min_size; 
		circles[i] = {id: i, r: size_r, cx: x, cy: y, 
					  mass: Math.pow(size_r, 2) * Math.PI * density,
					  speedX: Math.random() * max_speed, 
					  speedY: Math.random() * max_speed,
					  elasticity: 0.9, 
					  accelerationXFactors: { drag: 0, player: 0 }, 
					  accelerationYFactors: { drag: 0, player: 0, gravity: 0 },
					  accelerate(force, x_component, y_component) {
						  this.accelerationX = this.mass / (force * x_component);
						  this.accelerationY = this.mass / (force * y_component);
					  }
					 }; 
		
		// Circles are generated in fixed size blocks. TODO: This can be 
		// optimised to fit more circles into the stage. 
		if(x + 2 * max_size >= systemParamaters.boundsX) {
			x = max_size;
			y = y + 2 * max_size; 
		} else {
			x += 2 * max_size;
		}
		
		// If there's no more space, break loop. 
		if(y + max_size > systemParamaters.boundsY) {
			i = circle_number; 
		}
	}
	
	// Actually put the circles onto the stage. For clarity, this is done in a 
	// second loop. 
	let svgns = "http://www.w3.org/2000/svg";
	for(i = 0; i < circles.length; i++) {
		let circle = document.createElementNS(svgns, 'circle');
		circle.setAttributeNS(null, 'cx', circles[i].cx);
		circle.setAttributeNS(null, 'cy', circles[i].cy);
		circle.setAttributeNS(null, 'r', circles[i].r);
		circle.setAttributeNS(null, 'id', 'circle_' + circles[i].id);
		circle.setAttributeNS(null, 'style', 'fill: none; stroke: blue;')
		svg.appendChild(circle);
	}
	
	return circles; 
}

// For reference. 
//A circle has: 
/*
id
cx
cy
mass
speedX
speedY
elasticity
accelerationX, accelerationY
accelerate(force, direction{speedX, speedY})
*/