'use strict'; 

function enablePlayerControls(systemParamaters) {
    let circles = systemParamaters.circles; 

    let controls_listeners_keydown = (event => {
        if (event.keyCode == 40) {
            for(let i = 0; i < circles.length; i++) {
                if(circles[i].accelerationYFactors.player < 0.01) {
                    circles[i].accelerationYFactors.player += 0.001;
                } 
            }
        }

        if (event.keyCode == 38) {
            for(let i = 0; i < circles.length; i++) {
                if(circles[i].accelerationYFactors.player > -0.01) {
                    circles[i].accelerationYFactors.player -= 0.001;
                }
            }
        }

        if (event.keyCode == 39) {
            for(let i = 0; i < circles.length; i++) {
                if(circles[i].accelerationXFactors.player < 0.01) {
                    circles[i].accelerationXFactors.player += 0.001;
                }
            }
        }

        if (event.keyCode == 37) {
            for(let i = 0; i < circles.length; i++) {
                if(circles[i].accelerationXFactors.player > -0.01) {
                    circles[i].accelerationXFactors.player -= 0.001;
                }
            }
        }
    });
    
    
    window.addEventListener("keydown", controls_listeners_keydown, true);

    let controls_listeners_keyup = (event => {
        if (event.keyCode == 40 | event.keyCode == 38) {
            for(let i = 0; i < circles.length; i++) {
                circles[i].accelerationYFactors.player = 0;
            }
        }

        if (event.keyCode == 39 | event.keyCode == 37) {
            for(let i = 0; i < circles.length; i++) {
                 circles[i].accelerationXFactors.player = 0;
            }
        }
    });
    
    window.addEventListener("keyup", controls_listeners_keyup, true); 
    
    return {controls_listeners_keydown, controls_listeners_keyup};

}