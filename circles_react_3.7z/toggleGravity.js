class toggleGravityButton extends React.Component {
    constructor(props) {
        super(props);
        this.state = { toggled: false };
    }

    render() {
        return React.createElement(
            'button',
            {   id: "toggle_gravity_button",
                className: "btn-primary",
                onClick: () => {
                    this.toggleGravity();
                    this.toggle_button_status(); 
                }
            },
            'Toggle Gravity'
        )
    }

    toggleGravity() {
        this.state.toggled = !this.state.toggled;
        if(this.state.toggled) {
            this.props.settings.gravity = true;
        } else {
            this.props.settings.gravity = false;
        }
    }

    toggle_button_status() {
        if(this.state.toggled) {
            let thisButton = document.querySelector('#toggle_gravity_button');
            thisButton.classList.remove("btn-primary");
            thisButton.classList.add("btn-success");
        } else {
            let thisButton = document.querySelector('#toggle_gravity_button');
            thisButton.classList.remove("btn-success");
            thisButton.classList.add("btn-primary");
        }
    }
}